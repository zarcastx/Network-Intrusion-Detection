# GitHub Upload Checklist

1. Create a new repository at https://github.com/new (suggested name: CSET312-AI-Network-Intrusion-Detection).
2. Upload all included package files and folders using Add file > Upload files.
3. Download YOUR EXECUTED Google Colab notebook through File > Download > Download .ipynb. Rename to CSET312_AI_Network_Intrusion_Detection.ipynb and upload.
4. Add demo_upload.csv from your own downloaded Colab experiment output ZIP.
5. selected_model.joblib is optional for a public repository. Include if the size permits and you are comfortable sharing the model. Otherwise keep it locally; notebook regenerates it. Do not publish credentials.
6. Optionally upload the original test_confusion_matrix.png from Colab under screenshots/.
7. Paste your ACTUAL GitHub repository URL into Section 3.6.2 of the Word report.
8. Complete mentor, team, enrollment numbers, date and any signatures before submitting.
9. Check that the executed notebook matches the sampling and evaluation methods described in README.
